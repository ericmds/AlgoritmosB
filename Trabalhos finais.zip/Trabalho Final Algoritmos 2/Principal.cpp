#include <iostream>
#include <locale.h>
#include "Util.h"

using namespace std;

int main() {
    system("cls");
    setlocale(LC_ALL, "pt_BR.UTF-8");

    Degustacao vetor[TAM];
    string nomeArquivo = "baseDados.csv";
    int quantidadeRegistros = conectarBase(nomeArquivo, vetor, TAM);

    cout << "Bem vindo ao Sistema de Degustacao de Alimentos\n";
    cout << "Voce esta utilizando a base de dados: " << nomeArquivo << "\n";
    cout << "Registros carregados: " << quantidadeRegistros << "\n";

    int opcao;

    while (true) {
        cout << "\n--- Menu ---\n";
        cout << "1 - Cadastrar\n";
        cout << "2 - Listar\n";
        cout << "3 - Remover\n";
        cout << "4 - Pesquisar\n";
        cout << "5 - Sair\n";
        cout << "Opcao: ";

        cin >> opcao;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Entrada invalida. Por favor, insira um numero entre 1 e 5.\n";
            continue;
        }

        if (opcao < 1 || opcao > 5) {
            cout << "Opcao invalida. Por favor, insira de 1 a 5.\n";
            continue;
        }

        switch (opcao) {
            case 1:
                cadastrar(vetor, quantidadeRegistros, TAM, nomeArquivo);
                break;
            case 2:
                listar(vetor, quantidadeRegistros);
                break;
            case 3:
                remover(vetor, quantidadeRegistros, nomeArquivo);
                break;
            case 4:
                pesquisar(vetor, quantidadeRegistros);
                break;
            case 5:
                cout << "Saindo...\n";
                return 0;
        }
    }
}

// g++ Principal.cpp -o roda
// ./roda