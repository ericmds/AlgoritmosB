#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <cctype>

#define TAM 1000

using namespace std;

struct Degustacao {
    string nomeAlimento;
    string tipoAlimento;
    string dataDegustacao;
    string fabricante;
    int nota;
    string comentario;
};


void split(string vetor[], string linha, string delimitador = ";") {        
    int pos = 0;
    int index = 0;
    size_t found;

    while ((found = linha.find(delimitador, pos)) != string::npos) {
        vetor[index++] = linha.substr(pos, found - pos);
        pos = found + delimitador.size();
    }

    vetor[index] = linha.substr(pos);
}

string toLower(const string &s) {
    string r = s;
    transform(r.begin(), r.end(), r.begin(),[](unsigned char c) { 
        return tolower(c); 
        });
    return r;
}


int conectarBase(string baseDados, Degustacao vetor[], int tamanho) {
    ifstream arquivo(baseDados);

    if (!arquivo) {
        cout << "Erro! Base de dados nao encontrada...\n";
        return 0;
    }

    string linha;
    string partes[6];
    int qtd = 0;

    while (getline(arquivo, linha)) {

        if (linha.empty()) {
            continue;
        }

        if (qtd >= tamanho) {
            cout << "Vetor cheio! Nao foi possivel carregar mais registros.\n";
            break;
        }

        split(partes, linha, ";");

        vetor[qtd].nomeAlimento  = partes[0];
        vetor[qtd].tipoAlimento  = partes[1];
        vetor[qtd].dataDegustacao = partes[2];
        vetor[qtd].fabricante = partes[3];
        vetor[qtd].nota = stoi(partes[4]);
        vetor[qtd].comentario = partes[5];

        qtd++;
    }

    return qtd;
}

void cadastrar(Degustacao vetor[], int &qtd, int tamanho, string arquivoCSV) {
    if (qtd >= tamanho) {
        cout << "Vetor cheio! N�o � poss�vel cadastrar mais.\n";
        return;
    }

    cin.ignore();

    Degustacao d;

    cout << "*** Cadastro de Nova Degustacao ***\n";

    cout << "Nome do Alimento: ";
    getline(cin, d.nomeAlimento);

    cout << "Tipo de Alimento: ";
    getline(cin, d.tipoAlimento);

    cout << "Data da Degustacao: ";
    getline(cin, d.dataDegustacao);

    cout << "Fabricante: ";
    getline(cin, d.fabricante);

    cout << "Nota (0-5): ";
    cin >> d.nota;

    if (cin.fail() || d.nota < 0 || d.nota > 5) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Nota invalida! Deve ser entre 0 e 5.\n";
        return;
    }

    cin.ignore();

    cout << "Comentario: ";
    getline(cin, d.comentario);

    vetor[qtd] = d;
    qtd++;

    ofstream arquivo(arquivoCSV, ios::app);

    if (!arquivo) {
        cout << "Erro ao abrir arquivo para salvar!\n";
        return;
    }

    arquivo << d.nomeAlimento << ";"
            << d.tipoAlimento << ";"
            << d.dataDegustacao << ";"
            << d.fabricante << ";"
            << d.nota << ";"
            << d.comentario << "\n";

    arquivo.close();

    cout << "Registro salvo com sucesso!\n";
}

void listar(const Degustacao vetor[], int qtd) {
    if (qtd == 0) {
        cout << "Nenhum registro para listar.\n";
        return;
    }

    for (int i = 0; i < qtd; i++) {
        cout << "\nRegistro " << i + 1 << ":\n";
        cout << "Nome do Alimento: " << vetor[i].nomeAlimento << "\n";
        cout << "Tipo de Alimento: " << vetor[i].tipoAlimento << "\n";
        cout << "Data da Degustacao: " << vetor[i].dataDegustacao << "\n";
        cout << "Fabricante: " << vetor[i].fabricante << "\n";
        cout << "Nota: " << vetor[i].nota << "\n";
        cout << "Comentario: " << vetor[i].comentario << "\n";
        cout << "----------------------------\n";
    }
}

void pesquisar(const Degustacao vetor[], int qtd) {
    if (qtd == 0) {
        cout << "Nenhum registro para pesquisar.\n";
        return;
    }

    cin.ignore();

    string pesquisa;
    cout << "Digite o nome ou fabricante para pesquisar: ";
    getline(cin, pesquisa);

    string pesquisaLower = toLower(pesquisa);
    bool encontrado = false;

    for (int i = 0; i < qtd; i++) {
        string nome = toLower(vetor[i].nomeAlimento);
        string fab  = toLower(vetor[i].fabricante);

        if (nome.find(pesquisaLower) != string::npos || fab.find(pesquisaLower) != string::npos) {
            encontrado = true;

            cout << "\n--- Registro Encontrado ---\n";
            cout << "Nome: " << vetor[i].nomeAlimento << "\n";
            cout << "Tipo: " << vetor[i].tipoAlimento << "\n";
            cout << "Data: " << vetor[i].dataDegustacao << "\n";
            cout << "Fabricante: " << vetor[i].fabricante << "\n";
            cout << "Nota: " << vetor[i].nota << "\n";
            cout << "Comentario: " << vetor[i].comentario << "\n";
            cout << "----------------------------\n";
        }
    }

    if (!encontrado) {
        cout << "Nenhum registro correspondente foi encontrado.\n";
    }
}

void remover(Degustacao vetor[], int &qtd, string arquivoCSV) {
    if (qtd == 0) {
        cout << "Nenhum registro para remover.\n";
        return;
    }

    cin.ignore();

    string nome;
    cout << "Digite o nome exato do alimento a remover: ";
    getline(cin, nome);

    string nomeLower = toLower(nome);
    bool encontrado = false;

    for (int i = 0; i < qtd; i++) {
        if (toLower(vetor[i].nomeAlimento) == nomeLower) {

            for (int j = i; j < qtd - 1; j++) {
                vetor[j] = vetor[j + 1];
            }

            qtd--;
            encontrado = true;
            cout << "Registro removido com sucesso!\n";
            break;
        }
    }

    if (!encontrado) {
        cout << "Nenhum alimento encontrado com esse nome.\n";
        return;
    }

    ofstream arquivo(arquivoCSV);

    if (!arquivo) {
        cout << "Erro ao atualizar base de dados.\n";
        return;
    }

    for (int i = 0; i < qtd; i++) {
        arquivo << vetor[i].nomeAlimento << ";"
                << vetor[i].tipoAlimento << ";"
                << vetor[i].dataDegustacao << ";"
                << vetor[i].fabricante << ";"
                << vetor[i].nota << ";"
                << vetor[i].comentario << "\n";
    }
}